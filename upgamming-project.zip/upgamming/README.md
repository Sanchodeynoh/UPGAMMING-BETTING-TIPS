# UPGAMMING BETTING TIPS

A two-part project:
- **frontend/** — static site (HTML/CSS/JS), deployable on GitHub Pages
- **backend/** — Node.js + Express API, deployable on Render

The frontend calls the backend's `/api/matches/:date` endpoint to load match
data for whichever date is selected in the date picker.

---

## 1. Deploy the backend on Render

1. Push this whole project to a GitHub repository (see step 3 below first if
   you haven't already, then come back here).
2. Go to https://render.com and sign in (GitHub login works fine).
3. Click **New +** → **Web Service**.
4. Connect your GitHub repo.
5. When configuring the service:
   - **Root Directory**: `backend`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: Free is fine to start.
6. Click **Create Web Service**. Render will build and deploy it.
7. Once deployed, Render gives you a URL like:
   `https://upgamming-backend.onrender.com`
8. Test it by visiting `https://upgamming-backend.onrender.com/api/matches/2026-06-28`
   in your browser — you should see JSON data.

Note: On Render's free tier, the service spins down after inactivity and
takes a few seconds to "wake up" on the next request — that's expected.

---

## 2. Connect the frontend to your backend

1. Open `frontend/config.js`.
2. Replace the placeholder URL with your actual Render URL:

   ```js
   const API_BASE_URL = "https://upgamming-backend.onrender.com";
   ```

3. Save the file.

---

## 3. Deploy the frontend on GitHub Pages

1. Create a new repository on GitHub (e.g. `upgamming-tips`).
2. From this project's root folder, initialize git and push everything
   (both `frontend/` and `backend/` folders can live in the same repo):

   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
   git push -u origin main
   ```

3. On GitHub, go to your repo → **Settings** → **Pages**.
4. Under **Build and deployment**:
   - **Source**: Deploy from a branch
   - **Branch**: `main`
   - **Folder**: `/frontend` (if GitHub Pages gives you that option) —
     otherwise see the note below.
5. Save. GitHub will give you a live URL like:
   `https://YOUR-USERNAME.github.io/YOUR-REPO/`

### Note on the `/frontend` subfolder

GitHub Pages' folder dropdown only offers `/ (root)` or `/docs`, not custom
folder names. You have two options:

**Option A (simplest):** Move the contents of `frontend/` into the repo
root (or into a `docs/` folder) so GitHub Pages can serve it directly.

**Option B:** Keep the structure as-is and instead create a **separate
GitHub repository** just for the frontend files (copy only what's inside
`frontend/` into that repo), then enable Pages on that repo's root.

Either approach works — Option B keeps frontend and backend code cleanly
separated, which is generally tidier for two independently deployed
services.

---

## 4. Update CORS once you know your frontend URL (optional but recommended)

In `backend/server.js`, you'll see:

```js
app.use(cors({ origin: "*" }));
```

Once your GitHub Pages URL is live, you can lock this down to just your
frontend's origin for better security:

```js
app.use(cors({ origin: "https://YOUR-USERNAME.github.io" }));
```

Commit and push that change — Render will auto-redeploy.

---

## Adding more match data

Edit `backend/data.js` and add new date keys (format: `YYYY-MM-DD`) following
the existing structure. No frontend changes needed — it always fetches
whatever the backend returns.

## Local development

**Backend:**
```bash
cd backend
npm install
npm start
```
Runs on `http://localhost:3000`.

**Frontend:**
Just open `frontend/index.html` in a browser, after setting `API_BASE_URL`
in `config.js` to `http://localhost:3000` for local testing.
